import Navigation from "@/components/Navigation";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { CheckCircle2, AlertCircle, TrendingUp, Calendar, CreditCard, Smartphone, Receipt } from "lucide-react";
import { RadialBarChart, RadialBar, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

const creditScoreData = [
  { name: "Score", value: 75, fill: "#06B6D4" },
];

const factorData = [
  { name: "UPI Usage", value: 85, color: "#06B6D4" },
  { name: "Bill Payments", value: 78, color: "#6366F1" },
  { name: "Spending Pattern", value: 82, color: "#8B5CF6" },
  { name: "Mobile Activity", value: 72, color: "#EC4899" },
];

const factors = [
  {
    icon: Smartphone,
    title: "Mobile & Digital Activity",
    score: 72,
    status: "Good",
    description: "Regular digital transactions detected",
  },
  {
    icon: CreditCard,
    title: "UPI Transaction Behavior",
    score: 85,
    status: "Excellent",
    description: "Consistent spending patterns",
  },
  {
    icon: Receipt,
    title: "Bill Payment History",
    score: 78,
    status: "Good",
    description: "Timely utility payments",
  },
  {
    icon: Calendar,
    title: "Account Age & Stability",
    score: 68,
    status: "Fair",
    description: "Building financial history",
  },
];

export default function CreditScore() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <main className="container mx-auto px-4 pt-24 pb-12">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Alternative Credit Score
          </h1>
          <p className="text-muted-foreground">AI-powered creditworthiness assessment</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Main Score Card */}
          <Card className="lg:col-span-2 p-8 bg-gradient-to-br from-primary/10 to-secondary/10 border-primary/30">
            <div className="flex flex-col md:flex-row items-center gap-8">
              <div className="relative">
                <ResponsiveContainer width={200} height={200}>
                  <RadialBarChart
                    cx="50%"
                    cy="50%"
                    innerRadius="60%"
                    outerRadius="90%"
                    data={creditScoreData}
                    startAngle={180}
                    endAngle={-180}
                  >
                    <RadialBar
                      background
                      dataKey="value"
                      cornerRadius={10}
                      fill="url(#colorGradient)"
                    />
                    <defs>
                      <linearGradient id="colorGradient" x1="0" y1="0" x2="1" y2="1">
                        <stop offset="0%" stopColor="#6366F1" />
                        <stop offset="100%" stopColor="#06B6D4" />
                      </linearGradient>
                    </defs>
                  </RadialBarChart>
                </ResponsiveContainer>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <div className="text-5xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                      750
                    </div>
                    <div className="text-sm text-muted-foreground">/ 1000</div>
                  </div>
                </div>
              </div>

              <div className="flex-1">
                <h2 className="text-2xl font-bold mb-2">Your Credit Score</h2>
                <p className="text-muted-foreground mb-4">
                  Your score is calculated using AI-based alternative data analysis
                </p>
                <div className="flex items-center gap-2 mb-4">
                  <CheckCircle2 className="w-5 h-5 text-success" />
                  <span className="text-success font-medium">Good Standing</span>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Score Range: 700-800</span>
                    <span className="font-medium text-success flex items-center gap-1">
                      <TrendingUp className="w-4 h-4" />
                      +25 this month
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </Card>

          {/* Quick Stats */}
          <Card className="p-6 bg-card">
            <h3 className="text-lg font-bold mb-4">Score Distribution</h3>
            <ResponsiveContainer width="100%" height={180}>
              <PieChart>
                <Pie
                  data={factorData}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={70}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {factorData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="mt-4 space-y-2">
              {factorData.map((factor, index) => (
                <div key={index} className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <div
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: factor.color }}
                    />
                    <span className="text-muted-foreground">{factor.name}</span>
                  </div>
                  <span className="font-medium">{factor.value}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Factors Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {factors.map((factor, index) => {
            const Icon = factor.icon;
            return (
              <Card key={index} className="p-6 bg-card hover:shadow-glow transition-all duration-300">
                <div className="flex items-start gap-4">
                  <div className="p-3 rounded-lg bg-primary/10">
                    <Icon className="w-6 h-6 text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-bold">{factor.title}</h3>
                      <span className="text-2xl font-bold text-primary">{factor.score}</span>
                    </div>
                    <Progress value={factor.score} className="mb-2" />
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">{factor.description}</span>
                      <span className="text-success font-medium">{factor.status}</span>
                    </div>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>

        {/* Improvement Tips */}
        <Card className="mt-6 p-6 bg-gradient-to-br from-secondary/5 to-primary/5 border-secondary/30">
          <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-secondary" />
            AI Recommendations to Improve Score
          </h3>
          <div className="space-y-3">
            <div className="flex items-start gap-3 p-3 rounded-lg bg-card/50">
              <CheckCircle2 className="w-5 h-5 text-success mt-0.5" />
              <p className="text-sm">Maintain consistent UPI transaction patterns for better score</p>
            </div>
            <div className="flex items-start gap-3 p-3 rounded-lg bg-card/50">
              <CheckCircle2 className="w-5 h-5 text-success mt-0.5" />
              <p className="text-sm">Set up auto-pay for recurring bills to improve payment history</p>
            </div>
            <div className="flex items-start gap-3 p-3 rounded-lg bg-card/50">
              <CheckCircle2 className="w-5 h-5 text-success mt-0.5" />
              <p className="text-sm">Increase digital engagement to strengthen your financial profile</p>
            </div>
          </div>
        </Card>
      </main>
    </div>
  );
}
