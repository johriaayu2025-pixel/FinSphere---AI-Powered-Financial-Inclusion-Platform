import Navigation from "@/components/Navigation";
import { Card } from "@/components/ui/card";
import { TrendingUp, TrendingDown, DollarSign, PiggyBank, CreditCard, AlertTriangle } from "lucide-react";
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

const spendingData = [
  { name: "Food", value: 3500, color: "#6366F1" },
  { name: "Transport", value: 1200, color: "#06B6D4" },
  { name: "Entertainment", value: 800, color: "#8B5CF6" },
  { name: "Bills", value: 2500, color: "#EC4899" },
  { name: "Shopping", value: 1800, color: "#F59E0B" },
];

const monthlyTrend = [
  { month: "Jan", income: 25000, expenses: 18000 },
  { month: "Feb", income: 27000, expenses: 19500 },
  { month: "Mar", income: 26000, expenses: 20000 },
  { month: "Apr", income: 28000, expenses: 18500 },
  { month: "May", income: 30000, expenses: 21000 },
  { month: "Jun", income: 32000, expenses: 22000 },
];

const aiInsights = [
  {
    icon: TrendingUp,
    text: "Your savings increased by 15% this month - Great job!",
    color: "text-success",
  },
  {
    icon: AlertTriangle,
    text: "Food spending up 20%. Consider meal planning.",
    color: "text-warning",
  },
  {
    icon: TrendingDown,
    text: "Entertainment spending decreased by 30% - Well managed!",
    color: "text-success",
  },
];

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <main className="container mx-auto px-4 pt-24 pb-12">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Financial Dashboard
          </h1>
          <p className="text-muted-foreground">Your complete financial overview powered by AI</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="p-6 bg-card border-primary/20 hover:shadow-glow transition-all duration-300">
            <div className="flex items-center justify-between mb-4">
              <DollarSign className="w-8 h-8 text-primary" />
              <span className="text-sm font-medium text-success flex items-center gap-1">
                <TrendingUp className="w-4 h-4" />
                +12%
              </span>
            </div>
            <h3 className="text-2xl font-bold mb-1">₹32,000</h3>
            <p className="text-sm text-muted-foreground">Total Balance</p>
          </Card>

          <Card className="p-6 bg-card border-secondary/20 hover:shadow-glow-secondary transition-all duration-300">
            <div className="flex items-center justify-between mb-4">
              <PiggyBank className="w-8 h-8 text-secondary" />
              <span className="text-sm font-medium text-success flex items-center gap-1">
                <TrendingUp className="w-4 h-4" />
                +15%
              </span>
            </div>
            <h3 className="text-2xl font-bold mb-1">₹8,500</h3>
            <p className="text-sm text-muted-foreground">Savings</p>
          </Card>

          <Card className="p-6 bg-card border-primary/20 hover:shadow-glow transition-all duration-300">
            <div className="flex items-center justify-between mb-4">
              <CreditCard className="w-8 h-8 text-primary" />
              <span className="text-sm font-medium text-warning flex items-center gap-1">
                <TrendingUp className="w-4 h-4" />
                +8%
              </span>
            </div>
            <h3 className="text-2xl font-bold mb-1">₹22,000</h3>
            <p className="text-sm text-muted-foreground">Total Expenses</p>
          </Card>

          <Card className="p-6 bg-card border-secondary/20 hover:shadow-glow-secondary transition-all duration-300">
            <div className="flex items-center justify-between mb-4">
              <AlertTriangle className="w-8 h-8 text-secondary" />
              <span className="text-sm font-medium text-success">Low Risk</span>
            </div>
            <h3 className="text-2xl font-bold mb-1">750</h3>
            <p className="text-sm text-muted-foreground">Credit Score</p>
          </Card>
        </div>

        {/* AI Insights */}
        <Card className="p-6 mb-8 bg-gradient-to-br from-primary/5 to-secondary/5 border-primary/30">
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-primary animate-pulse-glow" />
            AI Financial Insights
          </h2>
          <div className="space-y-3">
            {aiInsights.map((insight, index) => {
              const Icon = insight.icon;
              return (
                <div key={index} className="flex items-start gap-3 p-3 rounded-lg bg-card/50">
                  <Icon className={`w-5 h-5 mt-0.5 ${insight.color}`} />
                  <p className="text-sm text-foreground/90">{insight.text}</p>
                </div>
              );
            })}
          </div>
        </Card>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="p-6 bg-card">
            <h2 className="text-xl font-bold mb-6">Spending Breakdown</h2>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={spendingData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {spendingData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </Card>

          <Card className="p-6 bg-card">
            <h2 className="text-xl font-bold mb-6">Income vs Expenses</h2>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={monthlyTrend}>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" />
                <XAxis dataKey="month" stroke="#888" />
                <YAxis stroke="#888" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "8px",
                  }}
                />
                <Legend />
                <Line type="monotone" dataKey="income" stroke="#06B6D4" strokeWidth={2} />
                <Line type="monotone" dataKey="expenses" stroke="#6366F1" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </Card>
        </div>
      </main>
    </div>
  );
}
